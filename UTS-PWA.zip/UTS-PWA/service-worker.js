self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open('my-pwa-cache').then(function(cache) {
            return cache.addAll([
                './',
                'index.html',
                'style.css',
                'manifest.json',
                'main.js',
                'icon.png',
                'profil.jpeg'
            ]);
        })
    );
});

self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request).then(function(response) {
            return response || fetch(event.request);
        })
    );
});

// Menambahkan event listener untuk menerima dan menampilkan notifikasi push
self.addEventListener('push', function(event) {
    const options = {
        body: event.data.text(),
        icon: 'icon.png',
    };

    event.waitUntil(
        self.registration.showNotification('FadlanHS Notification', options)
    );
});

// Memeriksa apakah Service Worker didukung oleh browser
if ('serviceWorker' in navigator) {
    // Mendaftarkan Service Worker
    navigator.serviceWorker.register('service-worker.js')
        .then(function(registration) {
            console.log('Service Worker registered with scope:', registration.scope);

            // Meminta izin notifikasi saat Service Worker terdaftar
            if ('Notification' in window && Notification.permission !== 'granted') {
                Notification.requestPermission().then(function(permission) {
                    if (permission === 'granted') {
                        console.log('Izin notifikasi diberikan.');
                    }
                });
            }
        })
        .catch(function(error) {
            console.error('Service Worker registration failed:', error);
        });
}

function saveCommentToIndexedDB(comment) {
    const request = indexedDB.open('CommentsDB', 1);

    request.onupgradeneeded = function(event) {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('comments')) {
            const objectStore = db.createObjectStore('comments', { keyPath: 'id', autoIncrement: true });
            objectStore.createIndex('text', 'text', { unique: false });
        }
    };

    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['comments'], 'readwrite');
        const objectStore = transaction.objectStore('comments');
        const request = objectStore.add({ text: comment });

        request.onsuccess = function() {
            console.log('Komentar tersimpan di IndexedDB');
        };

        transaction.oncomplete = function() {
            db.close();
        };
    };
}

function showCommentsFromIndexedDB() {
    const request = indexedDB.open('CommentsDB', 1);

    request.onupgradeneeded = function(event) {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('comments')) {
            const objectStore = db.createObjectStore('comments', { keyPath: 'id', autoIncrement: true });
            objectStore.createIndex('text', 'text', { unique: false });
        }
    };

    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['comments'], 'readonly');
        const objectStore = transaction.objectStore('comments');
        const commentsTable = document.getElementById('comments-table');

        // Hapus semua baris tabel sebelum menambahkan yang baru
        while (commentsTable.rows.length > 1) {
            commentsTable.deleteRow(1);
        }

        objectStore.openCursor().onsuccess = function(event) {
            const cursor = event.target.result;
            if (cursor) {
                const row = commentsTable.insertRow(1);
                const cell = row.insertCell(0);
                cell.textContent = cursor.value.text;
                cursor.continue();
            }
        };
    };
}

// Menunjukkan komentar dari IndexedDB saat halaman dimuat
showCommentsFromIndexedDB();

// Menangani pengiriman komentar dan menampilkan notifikasi
document.getElementById('comment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const commentInput = document.getElementById('comment');
    const comment = commentInput.value;
    if (comment) {
        // Simpan komentar ke IndexedDB
        saveCommentToIndexedDB(comment);
        commentInput.value = '';

        // Tampilkan komentar terbaru dari IndexedDB
        showCommentsFromIndexedDB();

        // Tampilkan notifikasi setelah komentar dikirim
        showNotification();
    }
});

// Menampilkan notifikasi PWA (memerlukan izin pengguna)
function showNotification() {
    if ('Notification' in window) {
        if (Notification.permission === 'granted') {
            // Izin notifikasi telah diberikan, maka tampilkan notifikasi
            const notification = new Notification('FadlanHS Notification', {
                body: 'Terima Kasih Atas Komentarnya',
                icon: 'icon.png'
            });

            notification.onclick = function() {
                console.log('Notifikasi diklik.');
            };
        } else if (Notification.permission !== 'denied') {
            // Minta izin notifikasi jika belum diberikan
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    showNotification(); // Tampilkan notifikasi setelah izin diberikan
                }
            });
        }
    }
}
